const sql = require('./connection')

const studMod = function(stud){
    this.Unit_Code = stud.Unit_Code,
    this.Teach_Period = stud.Teach_Period,
    this.Person_ID = stud.Person_ID
}


studMod.addAllStudent = (student)=>{
    return new Promise((resolve, reject)=>{
        sql.query('INSERT INTO Student_Module (Person_ID, Surname, Title, Given_Names, Teach_Period, Unit_Code, Team_ID, Email, Final_Result) VALUES'+ student,(err, data)=>{
            if(err){
                reject(err)
            }else{
                resolve('Added')
            }
        })
        
    })
}

studMod.saveStudent = (student)=>{
    return new Promise((resolve, reject)=>{
        sql.query('INSERT INTO Student_Module (Person_ID, Surname, Title, Given_Names, Teach_Period, Unit_Code, Team_ID, Email, Final_Result) VALUES '+student, (err, data)=>{
        if(err){
            reject(err)
        }else{
            resolve('Added')
        }
    })
    })
}

studMod.getStudent = (Unit_Code, Teach_Period) =>{
    return new Promise((resolve, reject)=>{
        sql.query('SELECT * FROM Student_Module WHERE Unit_Code = ? AND Teach_Period = ? ORDER BY Team_ID',[Unit_Code, Teach_Period],(err, data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
        })
    })
}

studMod.getAllData = (Unit_Code)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`SELECT * FROM Student_Module WHERE Unit_Code = '${Unit_Code}' ORDER BY Team_ID`, (err, data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
        })
    })
}



module.exports = studMod