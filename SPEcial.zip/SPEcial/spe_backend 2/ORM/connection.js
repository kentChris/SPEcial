const sql = require('mysql2')

const connection = sql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'kent123',
    database: 'SPEcial'
})

connection.connect(err=>{
    if (err){
        console.log('SQL Connection Error')
    }
    console.log('Succesfull SQL connection')
})

module.exports = connection