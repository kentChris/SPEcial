
const sql = require('./connection')

const UC = function(UC){
    this.UC_ID = customer.UC_ID;
    this.Password = customer.Password;
    this.Email = customer.Email;
    this.Name = customer.Name;
    this.Image = customer.Image;
}

UC.findById = (ID) =>{

    return new Promise((resolve, reject)=>{
        sql.query(`SELECT * FROM Unit_Coordinator WHERE UC_ID = ${ID}`,(err,data)=>{
            if(err){
                console.log(err)
                reject(err)
            }

            if(data.length){
                resolve(data)
            }

            resolve('Not Found')
        })
    })
}

UC.updateByEmail = (email, password)=>{
   
    return new Promise((resolve,reject)=>{
        sql.query('UPDATE Unit_Coordinator SET Password = ? WHERE Email = ?',
        [password, email],
        (err, res)=>{
        if(err){
            reject('Error')
            console.log('error')
        }else{
        resolve('UPDATED')
        console.log('updated')
        }
    })
    })
    
}

UC.saveUC = (UC_ID, Email, password, Name, Image)=>{
    return new Promise((resolve,reject)=>{
        sql.query('INSERT INTO Unit_Coordinator (UC_ID, Password, Email, Name, Image) VALUES (?, ?, ?, ?, ?)',[UC_ID, Email, password, Name, Image],(err, data)=>{
            if(err){
                reject('Error')
            }else{
                resolve('Added')
            }
        })
    })
}

module.exports = UC;