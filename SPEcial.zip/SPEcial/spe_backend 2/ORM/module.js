const sql = require('./connection')


const Module = function(module){
    this.Unit_Code = module.Unit_Code,
    this.Teach_Period = module.Teach_Period,
    this.Name = module.Name,
    this.UC_ID = module.UC_ID
}

Module.getDataByAdmin = (Teach_Period) =>{
    return new Promise((resolve, reject)=>{
        sql.query(`SELECT * FROM Module WHERE Teach_Period= ?`,[Teach_Period],(err, data)=>{
            if(err){
                reject('Error')
            }
            if(data){
                resolve(data)
            }

            resolve('Not Found')
        })
    })
}

Module.getDataByUser = (Teach_Period, User) =>{
    return new Promise((resolve, reject)=>{
        sql.query(`SELECT * FROM Module WHERE Teach_Period= ? AND UC_ID= ?`,[Teach_Period, User],(err, data)=>{
            if(err){
                console.log('something is wrong')
                reject('Error')
            }
            if(data){
                resolve(data)
            }
            resolve('Not Found')
        })
    })
}

Module.saveMod = (Unit_Code, UC_ID, Mod_Name, Teach_Period) =>{
    return new Promise((resolve, reject)=>{
        sql.query('INSERT INTO Module (Unit_Code, Teach_Period, Name, UC_ID) VALUES (?, ?, ?, ?)',[Unit_Code, UC_ID, Mod_Name, Teach_Period], (err, res)=>{
            if(err){
                reject('Error')
            }else{
                resolve('Added')
            }

        })
    })
}

Module.searchModAndUcByAdmin = (Unit_Code, Teach_Period) => {
    return new Promise((resolve, reject)=>{
        sql.query('select m.Name,m.UC_ID, uc.Email, uc.UC_Name, uc.Image from Module AS m, Unit_Coordinator AS uc WHERE m.Unit_Code = ? AND m.Teach_Period = ? AND uc.UC_ID = m.UC_ID',
        [Unit_Code, Teach_Period],(err,data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
            resolve('NOTOKAY')
        })
    })
}

Module.searchModAndUc = (Unit_Code, Teach_Period) => {
    return new Promise((resolve, reject)=>{
        sql.query('select m.Name,m.UC_ID, uc.Email, uc.UC_Name, uc.Image from Module AS m, Unit_Coordinator AS uc WHERE m.Unit_Code = ? AND m.Teach_Period = ? AND uc.UC_ID = 111111',
        [Unit_Code, Teach_Period],(err,data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
            resolve('NOTOKAY')
        })
    })
}


module.exports = Module