
const sql = require('./connection')


const studentSPE = function(SPE){
    this.Unit_Code = SPE.Unit_Code,
    this.Teach_Period = SPE.Teach_Period,
    this.Person_ID = SPE.Person_ID
}

studentSPE.insertData = (result) =>{
    return new Promise((resolve, reject)=>{
        sql.query('INSERT INTO Student_SPE (Person_ID, Title, Unit_Code, Teach_Period, Answer_1, Answer_2, Answer_3, Answer_4, Answer_5, Teamate_ID, Comments, Score) VALUES '+result,(err,req)=>{
            if(err){
                console.log(err)
                reject('NOTOKAY')
            }else{
                resolve('OKAY')
            }
        })
    })
}

studentSPE.getAnswerAndQuestion = (Title, ID, Unit_Code, Teach_Period) =>{
    return new Promise((resolve, reject)=>{
        sql.query('SELECT spe.Question_1, spe.Question_2, spe.Question_3, spe.Question_4, spe.Question_5,sspe.Teamate_ID,'+
        'sspe.Answer_1, sspe.Answer_2, sspe.Answer_3, sspe.Answer_4, sspe.Answer_5,sspe.Comments,spe.Note, sm.Given_Names FROM '+
        'SPE as spe, Student_SPE as sspe, Student_Module as sm WHERE spe.Title = ? AND sspe.Title = ? AND sspe.Person_ID = ? AND sm.Person_ID = sspe.Teamate_ID AND spe.Unit_Code = ? AND sspe.Unit_Code = ? AND sm.Unit_Code = ? AND spe.Teach_Period = ? AND sspe.Teach_Period = ? AND sm.Teach_Period = ?',[Title, Title, ID, Unit_Code, Unit_Code, Unit_Code, Teach_Period, Teach_Period, Teach_Period], (err, data)=>{
            if(err){
                reject('NOTOKAY')

            }
            if(data){
                resolve(data)
            }
        })
    })
}

studentSPE.updateData=(Obj,user, title, percent, Unit_Code, Teach_Period)=>{
    return new Promise((resolve,reject)=>{
        sql.query(`UPDATE Student_SPE SET Answer_1 = '${Obj.Answer[0]}', Answer_2 = '${Obj.Answer[1] || ''}', Answer_3 = '${Obj.Answer[2] || ''}', Answer_4 = '${Obj.Answer[3] || ''}', Answer_5 = '${Obj.Answer[4] || ''}', Comments = '${Obj.Comments || ''}', Percentage = ${percent} WHERE Person_ID = '${user}' AND Teamate_ID = '${Obj.Teamate_ID}' AND Title = '${title}' AND Unit_Code = '${Unit_Code}' AND Teach_Period = '${Teach_Period}'`,(err, res)=>{
            if(err){
                console.log(err)
            }else{
                resolve('OKAY')
            }
        })
    })
}

studentSPE.getResult=(Unit_Code, Teach_Period)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`SELECT DISTINCT Person_ID, Title, Score FROM Student_SPE WHERE Unit_Code = '${Unit_Code}' AND Teach_Period = '${Teach_Period}' ORDER BY Person_ID, Title`, (err, data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
        })
    })
}

studentSPE.getReminderEmail=(Unit_Code, Teach_Period, Title)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`SELECT DISTINCT sspe.Person_ID, sspe.Percentage, sm.Title, sspe.Title as SPETitle, sm.Given_Names, sm.Email, sm.Unit_Code, sm.Teach_Period FROM
                Student_Spe as sspe, Student_Module as sm WHERE sm.Unit_Code = '${Unit_Code}' AND sspe.Unit_Code = '${Unit_Code}' AND sspe.Teach_Period = '${Teach_Period}' 
                AND sspe.Person_ID = sm.Person_ID AND sspe.Title = '${Title}'`,(err, data)=>{
                    if(err){
                        console.log(err)
                        reject('NOTOKAY')
                    }
                    if(data){
                        resolve(data)
                    }
                })
    }) 
}

studentSPE.getFinalScore=(Unit_Code, Teach_Period, Title)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`select distinct sspe.Person_ID, sspe.Percentage, sm.Title,sspe.Title as SPETitle, sm.Given_Names,spe.Counter, sm.Email, sm.Unit_Code, sm.Teach_Period FROM
                    Student_Spe as sspe, Student_Module as sm, SPE as spe WHERE sm.Unit_Code = '${Unit_Code}' AND sspe.Unit_Code = '${Unit_Code}' AND sspe.Teach_Period = '${Teach_Period}' 
                    AND sspe.Person_ID = sm.Person_ID AND spe.Title = sspe.Title AND sspe.Title = '${Title}'`,(err, data)=>{
                    if(err){
                        console.log(err)
                        reject('NOTOKAY')
                    }
                    if(data){
                        resolve(data)
                    }
                })
    }) 
}

studentSPE.getAnswer=(Unit_Code, Teach_Period, Title, Team)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`select * from Student_Spe WHERE Title='${Title}' AND Teamate_ID = '${Team}' AND Teach_Period = '${Teach_Period}' AND Unit_Code = '${Unit_Code}'`,(err, data)=>{
                    if(err){
                        console.log(err)
                        reject('NOTOKAY')
                    }
                    if(data){
                        resolve(data)
                    }
                })
    }) 
}

studentSPE.updateScore=(Unit_Code, Teach_Period, score, person)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`UPDATE Student_Spe SET Score = ${score} WHERE Person_ID = '${person}' AND Teach_Period = '${Teach_Period}' AND Unit_Code = '${Unit_Code}'`,(err, data)=>{
                    if(err){
                        console.log(err)
                        reject('NOTOKAY')
                    }else{
                        resolve('okay')
                    }
                    
                })
    }) 
}






module.exports = studentSPE

