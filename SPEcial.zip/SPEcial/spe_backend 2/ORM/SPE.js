
const sql = require('./connection')


const SPE = function(SPE){
    this.Unit_Code = SPE.Unit_Code,
    this.Teach_Period = SPE.Teach_Period,
    this.Person_ID = SPE.Person_ID
}

SPE.insertData = (result) =>{
    return new Promise((resolve, reject)=>{
        sql.query('INSERT INTO SPE (Title, Due_Date, Due_Time, Question_1, Question_2, Question_3, Question_4, Question_5, Counter, Unit_Code, Teach_Period, Note) VALUES '+result, (err, res)=>{
            if(err){
                console.log(err)
                reject('NOTOKAY')
            }else{
                resolve('OKAY')
            }
        })
    })
}

SPE.getSPE = (Unit_Code, Teach_Period) =>{
    return new Promise((resolve, reject)=>{
        sql.query(`SELECT * FROM SPE WHERE Unit_Code = '${Unit_Code}' AND Teach_Period = '${Teach_Period}'`, (err, data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
        })
    })
}

SPE.getAllData=()=>{
    return new Promise((resolve, reject)=>{
        sql.query('SELECT * FROM SPE',(err,data)=>{
            if(err){
                reject('NOTOKAY')
            }
            if(data){
                resolve(data)
            }
        })
    })
}

SPE.updateCalculated=(Unit_Code, Teach_Period, spe)=>{
    return new Promise((resolve, reject)=>{
        sql.query(`UPDATE SPE SET Calculated = true WHERE Teach_Period = '${Teach_Period}' AND Unit_Code = '${Unit_Code}' AND Title = '${spe}'`,(err, data)=>{
                    if(err){
                        console.log(err)
                        reject('NOTOKAY')
                    }else{
                        resolve('okay')
                    }
                    
                })
    }) 
}

module.exports = SPE

