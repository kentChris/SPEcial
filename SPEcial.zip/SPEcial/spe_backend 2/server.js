const express = require('express')
const app = express()
const jwt = require('jsonwebtoken')
const cors = require('cors')
const bodyParser = require('body-parser')
const cron = require('node-cron')


app.use(express.json())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
    extended: true
}))

const UC = require('./ORM/UC')


app.use(cors({
    origin: "http://localhost:3000"
}))

const date = new Date();
let Teach_Period = ''
if(date.getMonth() === 0 || date.getMonth() === 1 || date.getMonth() === 2 || date.getMonth() === 3){
    Teach_Period = 'S1'+ date.getFullYear()
}else if(date.getMonth() === 4 || date.getMonth() === 5 || date.getMonth() === 6 || date.getMonth() === 7){
    Teach_Period = 'S2'+date.getFullYear()
}else{
    Teach_Period = 'S3'+date.getFullYear()
}

require('./authServer')(app)
require('./email')(app)
require('./dashboardAPI')(app, Teach_Period)
require('./moduleAPI')(app, Teach_Period)
require('./createSPE')(app, Teach_Period)
require('./SPE')(app, Teach_Period)
require('./scheadule')(cron)





app.listen(5000)