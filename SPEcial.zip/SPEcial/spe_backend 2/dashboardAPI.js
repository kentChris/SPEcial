 const Module = require('./ORM/module')
 const UC = require('./ORM/UC')
 const jwt = require('jsonwebtoken')
 require('dotenv').config()

 const authenticationToken = (req, res, next) =>{
    const auth = req.body.auth
    const token = auth && auth.split(' ')[1]
    if(token == null){
        res.send('NOTOKAY')
    }
    jwt.verify(token, process.env.SECRET, (err, user)=>{
        if(err){
            res.send('NOTOKAY')
        }
        req.user = user
        next()  
    })
}

module.exports = function(app, Teach_Period){


    app.post('/dashboardData',authenticationToken, (req, res)=>{
        if(req.user.ID === '111111'){
            Module.getDataByAdmin(Teach_Period)
            .then(data=>{
                res.json([{id:'admin',user:'111111'}, data])
            })
            .catch(err=>{
                console.log(err)
                res.send('Error')
            })
        }else{
            Module.getDataByUser(Teach_Period, req.user.ID)
            .then(data=>{
                res.json([{id:'user', user: req.user.ID}, data])
            })
            .catch(err=>{
                res.send('Error')
            })
        }
    })

    app.post('/register',authenticationToken, (req, res)=>{
        if(req.user.ID !== '111111'){
            res.send('Unsucessful')
        }
        UC.saveUC(req.body.UC_ID, req.body.password, req.body.Email, req.body.UC_Name, req.body.Image )
        .then(data=>{
            res.send('Succesful')
        }).catch(err=>res.send('Error'))
    } )


    app.post('/add', authenticationToken, (req, res)=>{
        if(req.user.ID !== '111111'){
            res.send('Unsuccesful')
        }

        Module.saveMod(req.body.Unit_Code, Teach_Period, req.body.Mod_Name, req.body.UC_ID)
        .then(data=>{
            res.send('Succesful')
        }).catch(err=>res.send('Error'))
    })

}