const nodemailer = require('nodemailer')
const jwt = require('jsonwebtoken')
const UC = require('./ORM/UC')
const sendGrid = require('@sendgrid/mail')

require('dotenv').config()

    sendGrid.setApiKey('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')

    const authenticationToken = (req, res, next) =>{
    const auth = req.body.auth
    const token = auth && auth.split(' ')[1] 
    if(token == null){
        res.send('NOTOKAY')
    }
    jwt.verify(token, process.env.EMAIL_SECRET, (err, user)=>{
        if(err){
            res.send('NOTOKAY')
        }
        req.email = user
        next()  
    })
}

module.exports = function(app){

    app.post('/email',(req,res)=>{
        const email = {email: req.query.email}

        const token = jwt.sign(email, process.env.EMAIL_SECRET,{expiresIn: '10m'})

        const message = {
            to: email.email,
            from: 'kentchrist6@gmail.com',
            subject: ' Reset password (Auto generated email)',
            text: 'Dear Mr/Mrs.UC,\n\n Please use this link to access the reset password page:\n'+
                  `http://localhost:3000/setPassword/${token} \n\n`+
                  'Best Regards,\n Team SPEcial'
        }

        sendGrid.send(message)
        .then(res.send('Sent'))
        .catch(err=> res.send('Error'))

    })

    //

    app.put('/reset',authenticationToken, (req,res)=>{
        const email = req.email.email
        const password = req.body.password

        UC.updateByEmail(email, password)
        .then(data=>{
            res.send(data)
        }).catch(err=>{
            res.send('Error')
        })


    })

}

