 const SPE = require('./ORM/SPE')
 const studMod = require('./ORM/StudMod')
 const studSPE = require('./ORM/Student_SPE')
 const jwt = require('jsonwebtoken')
 const nodemailer = require('nodemailer')
 require('dotenv').config()

 const authenticationToken = (req, res, next) =>{
    const auth = req.body.auth
    const token = auth && auth.split(' ')[1]
    if(token == null){
        res.send('NOTOKAY')
    }
    jwt.verify(token, process.env.SECRET, (err, user)=>{
        if(err){
            res.send('NOTOKAY')
        }
        req.user = user
        next()  
    })
}


module.exports = function(app, Teach_Period){

    app.post('/createSPE',authenticationToken, (req, res)=>{
        if(req.body.Question.length === 0){
            res.send('NOTOKAY')
        }
        studMod.getStudent(req.body.Unit_Code, Teach_Period).then(data=>{
            const question = req.body.Question
            const spe = req.body.SPE
            const unit = req.body.Unit_Code
            if(data === []){
                res.send('NOTOKAY')
            }else if(req.body.Unit_Code !== data[0].Unit_Code){
                res.send('NOTOKAY')
            }else{
            const result = `("${spe.Title}", "${spe.Date}", "${spe.Time}", "${question[0]}", "${question[1] || 'N/A'}", "${question[2] || 'N/A'}", "${question[3] || 'N/A'}", "${question[4] || 'N/A'}", ${question.length},"${unit}","${Teach_Period}", "${spe.Note}")`
                SPE.insertData(result).then(data1=>{
                    let result1 = ''
                    for(let i=0;i<data.length;i++){
                        for(let j=0; j<data.length;j++){
                            if(data[i].Team_ID === data[j].Team_ID){
                                result1 = result1 + `("${data[i].Person_ID}", "${spe.Title}", "${unit}", "${Teach_Period}", '','','','','', "${data[j].Person_ID}", "", 0.0), `
                            }
                        }
                    }
                    const result2 = result1.slice(0, -2)
                        studSPE.insertData(result2).then(data2=>{
                            sendMailStud(data, spe.Date, spe.Title, spe.Time, unit)
                            res.send('OKAY')
                        }).catch(err=>{
                            res.send('NOTOKAY')
                        })

                }).catch(err=>{
                    res.send('NOTOKAY')
                })
            }
        }).catch(err=>{
            res.send('NOTOKAY')
        })
    })

}

async function sendMailStud(students, date, SPE, SPETIME, unit){

    const transporter = nodemailer.createTransport({
        host: 'smtp.mailtrap.io',
        port: 25,
        auth: {
            user: '1a2d1e12df7d19',
            pass: 'a744c7a106af90'
        }
    })
    
    for(let i=0; i< students.length;i++){
        const date1 = new Date()
        const date2 = new Date(date+' '+SPETIME)
        const token = jwt.sign({Person_ID: students[i].Person_ID,Title:SPE, Unit_Code: students[0].Unit_Code}, process.env.STUDENT, {expiresIn:`${date2 - date1}`})
        const mailOptions = {
            from: 'SPEcial@gmail.com',
            to: students[i].Email,
            subject: `${SPE} (${students[i].Unit_Code}) `,
            text: `Dear ${students[i].Title}.${students[i].Given_Names},`+
            `\n This SPE will end on ${date} at ${SPETIME}`+
            `\n Please use this link to do your ${SPE} for Unit ${unit} . \n\n`+
                    `http://localhost:3000/SPE/${token} \n\n`+
                    'Best regards,\n SPEcial team',
        }

        transporter.sendMail(mailOptions, (err, info)=>{
            if(err){
                console.log(err)
            }else{
                console.log('sent')
            }
        })

        if(i % 3 === 0 && i !== 0){
            await sleep(12000)
        }

    }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}



        