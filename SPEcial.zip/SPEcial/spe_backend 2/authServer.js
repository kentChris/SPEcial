
const jwt = require('jsonwebtoken')
const UC = require('./ORM/UC')
require('dotenv').config()

module.exports = function(app){
    
    //To authenticate the login Page (/)
    app.post('/login', (req, res)=>{

    const username = req.query.username
    const password = req.query.password
    
    UC.findById(username)
    .then(data => {
        
        if(data[0].Password === password){
        const accessToken = generateToken({ID: req.query.username})
        res.json({accessToken: accessToken})
        }else{
        res.send('Unsucessful')
        }
    })
    .catch(console.log(err=>console.log(err)))
})

//     //Post method to check the token for all the page
//     app.post('/authenticate',(req, res)=>{
//         const auth = req.body.auth
//         const token = auth && auth.split(' ')[1]
//     if(token == null){
//         res.send('NOTOKAY')
//     }
//     jwt.verify(token, process.env.SECRET, (err, user)=>{
//         if(err){
//             res.send('NOTOKAY')
//         }
//         res.send('OKAY')
//     })
// })




}
const generateToken = (user) =>{
    return jwt.sign(user, process.env.SECRET, {expiresIn: '30m'})
}





