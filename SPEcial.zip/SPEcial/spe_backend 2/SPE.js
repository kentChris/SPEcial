 const Module = require('./ORM/module')
 const StudSPE = require('./ORM/Student_SPE')
 const UC = require('./ORM/UC')
 const jwt = require('jsonwebtoken')
const studentSPE = require('./ORM/Student_SPE')
 require('dotenv').config()

 const authenticationToken = (req, res, next) =>{
    const auth = req.body.auth
    const token = auth && auth.split(' ')[1]
    if(token == null){
        res.send('NOTOKAY')
    }
    jwt.verify(token, process.env.STUDENT, (err, user)=>{
        if(err){
            res.send('NOTOKAY')
        }
        req.user = user
        next()  
    })
}

module.exports = function(app, Teach_Period){

    app.post('/SPE', authenticationToken, (req, res)=>{
        let result = []
        Module.searchModAndUcByAdmin(req.user.Unit_Code, Teach_Period).then(data=>{
            console.log(req.user.Unit_Code)
            result = [req.user, data]
             StudSPE.getAnswerAndQuestion(req.user.Title, req.user.Person_ID, req.user.Unit_Code, Teach_Period).then(data1=>{
                 result[2] = data1[0].Note
                 const temp = getInsideData(data1)
                 result[3] = temp[0]
                 result[4] = temp[1]
                 result[5] = temp[2]
                 res.json(result)
             }).catch(err=>{
                 res.send('NOTOKAY')
             })
        }).catch(err=>{
            res.send('NOTOKAY')
        })
    })

    app.post('/saveSPE',authenticationToken, (req, res)=>{
        let counter = 0
        let devider = 0
        counter1 = 0
        for(let i=0;i<req.body.Obj.length;i++){
            for(let j=0; j<req.body.Obj[i].Answer.length;j++){
                if(req.body.Obj[i].Answer[j] === ''){
                    counter++
                }
                devider++
            }
        }
        let percent = ((devider - counter)/ devider) * 100

         for(let i=0;i<req.body.Obj.length;i++){
            studentSPE.updateData(req.body.Obj[i], req.user.Person_ID, req.user.Title, percent, req.user.Unit_Code, Teach_Period).then(data=>{
                counter1++
                if(counter1 === req.body.Obj.length){
                    res.send('OKAY')
                }
            }).catch(err=>{
                res.send('NOTOKAY')
            })
         }

    })

}


const getInsideData =(Obj)=>{
    let question = []
    let counter = 0
    let result = []
    let counter1 = 0
    let counterResult = 0
    let devider = 0

    for(let i=0; i<Obj.length;i++){

        let answer = []
        counter = 0
        if(Obj[i].Question_1 !== 'N/A'){
            question[counter] = Obj[i].Question_1
            answer[counter] = Obj[i].Answer_1
            counter++
            devider++
            if(Obj[i].Answer_1 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_2 !== 'N/A'){
            question[counter] = Obj[i].Question_2
            answer[counter] = Obj[i].Answer_2
            counter++
            devider++
            if(Obj[i].Answer_2 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_3 !== 'N/A'){
            question[counter] = Obj[i].Question_3
            answer[counter] = Obj[i].Answer_3
            counter++
            devider++
            if(Obj[i].Answer_3 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_4 !== 'N/A'){
            question[counter] = Obj[i].Question_4
            answer[counter] = Obj[i].Answer_4
            counter++
            devider++
            if(Obj[i].Answer_4 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_5 !== 'N/A'){
            question[counter] = Obj[i].Question_5
            answer[counter] = Obj[i].Answer_5
            counter++
            devider++
            if(Obj[i].Answer_5 === ''){
                counterResult++
            }
        }
        devider++
        if(Obj[i].Comments === ''){
            counterResult++
        }
        result.push({name:`${Obj[i].Given_Names} (${Obj[i].Teamate_ID})`,Teamate_ID: Obj[i].Teamate_ID, Answer: answer , Comments: Obj[i].Comments})
    }
        const percent = ((devider - counterResult)/devider) * 100
        return [result, question, percent.toFixed(2)]
}
