 const StudeSpe = require('./ORM/Student_SPE')
 require('dotenv').config()
 const SPE = require('./ORM/SPE')
 const nodemailer = require('nodemailer')

 const transporter = nodemailer.createTransport({
        host: 'smtp.mailtrap.io',
        port: 25,
        auth: {
            user: 'a6d43201927548',
            pass: '5842063609fa57'
        }
    })

module.exports= function(cron){
        cron.schedule('* * 3 */1 * *', ()=>{
            SPE.getAllData().then(data=>{
                let x = new Date()
                const utc = (x.getTime() + x.getTimezoneOffset()*60*1000);
                const now = new Date(utc + (3600000*8));
                for(let i=0;i<data.length;i++){
                    const DueDate = new Date(data[i].Due_Date.toDateString()+' '+ data[i].Due_Time)
                    const result = DueDate - now
                    const days = Math.floor(result / (24*60*60*1000));
                    if(days === 7){
                        StudeSpe.getReminderEmail(data[i].Unit_Code, data[i].Teach_Period, data[i].Title).then(data1=>{
                            let counter = 0
                            for(let j=0; j< data1.length;j++){
                                if(data1[j].Percentage != 100){
                                    emailReminder(data1[j])
                                    counter++
                                }
                                if(counter === 3){
                                    sleep(12000)
                                    counter = 0
                                }
                            }
                        }).catch(err=>{
                            console.log(err)
                        })
                    }else if(days === 1){
                        StudeSpe.getReminderEmail(data[i].Unit_Code, data[i].Teach_Period, data[i].Title).then(data1=>{
                            let counter = 0
                            for(let j=0; j< data1.length;j++){
                                if(data1[j].Percentage != 100){
                                    emailWarning(data1[j])
                                    counter++
                                }
                                if(counter === 3){
                                    sleep(12000)
                                    counter = 0
                                }
                            }
                        }).catch(err=>{
                            console.log(err)
                        })
                    }else if(days < 0 && data[i].Calculated !== 1){
                        console.log(data[i].Calculated)
                        StudeSpe.getFinalScore(data[i].Unit_Code, data[i].Teach_Period, data[i].Title).then(data1=>{
                            for(let j=0; j< data1.length;j++){
                                    if(data1[j].Percentage == 100){
                                        StudeSpe.getAnswer(data[i].Unit_Code, data[i].Teach_Period, data[i].Title, data1[j].Person_ID).then(data3=>{
                                                const temp =resultData(data3, data1[j].Counter)
                                                StudeSpe.updateScore(data[i].Unit_Code, data[i].Teach_Period, temp, data1[j].Person_ID).then(data4=>{
                                                    SPE.updateCalculated(data[i].Unit_Code, data[i].Teach_Period, data[i].Title).then(data5=>{
                                                        console.log(data[i].Title+' '+ data[i].Unit_Code+' :Calculation done')
                                                    }).catch(err=>{
                                                        console.log(err)
                                                    })
                                                }).catch(err=>{
                                                    console.log(err)
                                                })
                                        }).catch(err=>{
                                            console.log(err)
                                        })
                                    }else{
                                        SPE.updateCalculated(data[i].Unit_Code, data[i].Teach_Period, data[i].Title).then(data5=>{
                                            console.log(data[i].Title+' '+ data[i].Unit_Code+' :Calculation done')
                                        }).catch(err=>{
                                            console.log(err)
                                        })
                                    }
                            }
                        }).catch(err=>{
                            console.log(err)
                        })
                    }
                }
            }).catch(err=>{
                console.log(err)
            })
        },{
            scheduled: true,
            timezone : 'Asia/Singapore'
        })
}

const resultData=(data, counter1)=>{
    let result = 0
    let devider = 0
    for(let i=0;i<data.length;i++){
        if(counter1 == 5 && data[i].Percentage == 100){
            devider++
            result = result + parseInt(data[i].Answer_5)
            console.log('test1')
        }
        if(data[i].Percentage == 100){
            if(counter1 == 4 || counter1 == 5){
            devider++
            result = result + parseInt(data[i].Answer_4)
            console.log('test2')
            }
        }
        if(data[i].Percentage == 100){
            if(counter1 == 3 || counter1 == 4 || counter1 == 5){
            devider++
            result = result + parseInt(data[i].Answer_3)
            console.log('test3')
            }
        }
        if(data[i].Percentage == 100){
            if(counter1 == 5 || counter1 == 4 || counter1 == 3 || counter1 == 2){
            devider++
            result = result + parseInt(data[i].Answer_2)
            console.log('test4')
            }
        }
        if(data[i].Percentage == 100){
            if(counter1 == 1 || counter1 == 2 || counter1 == 3 || counter1 == 4 || counter1 == 5){
            devider++
            result = result + parseInt(data[i].Answer_1)
            console.log('test5')
            }
        }
    }
    console.log(result)
    return ((result/(5*devider))*100)
}

const emailReminder = (data) =>{
    const mailOptions = {
            from: 'SPEcial@gmail.com',
            to: data.Email,
            subject: `Email Reminder for ${data.SPETitle} (${data.Unit_Code}) `,
            text: `Dear ${data.Title}.${data.Given_Names},`+
            `\n This is a gentle reminder to do your ${data.SPETitle}. Please make sure to save the SPE until 100%.`+
            `\n If you did not finish the SPE on time, you will receive 0 marks on the SPE. \n\n`+
                    'Best regards,\n SPEcial team',
        }

        transporter.sendMail(mailOptions, (err, info)=>{
            if(err){
                console.log(err)
            }else{
                console.log('sent')
            }
        })
}

const emailWarning = (data) =>{
    const mailOptions = {
            from: 'SPEcial@gmail.com',
            to: data.Email,
            subject: `Email Warning for ${data.SPETitle} (${data.Unit_Code}) `,
            text: `Dear ${data.Title}.${data.Given_Names},`+
            `\n This is a final reminder for your ${data.SPETitle}. You have 1 more day to finish your SPE. Please make sure to save the SPE until 100% before the due date.`+
            ` If you did not finish the SPE on time, you will receive 0 marks on the SPE. \n\n`+
                    'Best regards,\n SPEcial team',
        }

        transporter.sendMail(mailOptions, (err, info)=>{
            if(err){
                console.log(err)
            }else{
                console.log('sent')
            }
        })
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}