 const Module = require('./ORM/module')
 const UC = require('./ORM/UC')
 const jwt = require('jsonwebtoken')
 const SPE = require('./ORM/SPE')
 const Stud = require('./ORM/StudMod')
 const studSPE = require('./ORM/Student_SPE')
 require('dotenv').config()

const authenticationToken = (req, res, next) =>{
    const auth = req.body.auth
    const token = auth && auth.split(' ')[1]
    if(token == null){
        res.send('NOTOKAY')
    }
    jwt.verify(token, process.env.SECRET, (err, user)=>{
        if(err){
            res.send('NOTOKAY')
        }
        req.user = user
        next()  
    })
}

module.exports = function(app, Teach_Period){

    app.post('/moduleData', authenticationToken,(req,res)=>{
        if(req.user.ID === '111111'){
            Module.searchModAndUcByAdmin(req.body.Unit_Code, Teach_Period)
            .then(data=>{
                    Stud.getAllData(req.body.Unit_Code).then(data1=>{
                        SPE.getSPE(req.body.Unit_Code, Teach_Period).then(data2=>{
                            res.json([{id:'admin', user:'111111'}, data[0], data1, data2])
                        }).catch(err=>{
                            res.send('NOTOKAY')
                        })
                    }).catch(err=>{
                        res.send('NOTOKAY')
                    })
            }).catch(err=>res.send('NOTOKAY'))
        }else{
           Module.searchModAndUc(req.body.Unit_Code, Teach_Period)
            .then(data=>{
                if(data[0].UC_ID === req.user.ID){
                    Stud.getAllData(req.body.Unit_Code).then(data1=>{
                        SPE.getSPE(req.body.Unit_Code, Teach_Period).then(data2=>{
                            res.json([{id:'user', user:req.user.ID}, data[0], data1, data2])
                        }).catch(err=>{
                            res.send('NOTOKAY')
                        })
                        
                    }).catch(err=>{
                        res.send('NOTOKAY')
                    })
                    
                }else{
                    res.send('NOTOKAY')
                }
            }).catch(err=>res.send('NOTOKAY'))
        }
    })

    app.post('/addStudents', authenticationToken, (req, res)=>{
        let result = '';
        for(let i=0; i<req.body.student.length;i++){

            if(Teach_Period === req.body.student[i].Teach_Period && req.body.Unit_Code === req.body.student[i].Unit_Code){
            const data = req.body.student[i]
            result= result + `('${data.Person_ID}', "${data.Surname}", "${data.Title}", "${data.Given_Names}", '${data.Teach_Period}', '${data.Unit_Code}', '${data.Team_ID}', "${data.Email}", 0.0), `
            }
        }
        const result2 = result.slice(0, -2)
        if(result2 === ''){
            res.send('NOTOKAY')
        }else{
            Stud.addAllStudent(result2).then(data=>{
            res.send('OKAY')
        }).catch(err=>{
            res.send('NOTOKAY')
        })

        }
    })

    app.post('/submitStudent', authenticationToken, (req, res)=>{
        const data = req.body.student
        if(Teach_Period === data.Teach_Period){
            const result= `('${data.Student_ID}', "${data.Surname}", "${data.Title}", "${data.Given_Name}", '${data.Teach_Period}', '${data.Unit_Code}', '${data.Team_ID}', "${data.Email}", 0.0) `
        }else{
            res.send('NOTOKAY')
        }
        
        
        Stud.saveStudent(result)
        .then(data=>{
            res.send('OKAY')
        }).catch(err=>{
            res.send('NOTOKAY')
        })
    })

    app.post('/getSpeData', authenticationToken, (req,res)=>{
        if(req.body.SPE !== '' || req.body.student !== ''){
             studSPE.getAnswerAndQuestion(req.body.SPE, req.body.student, req.body.Unit_Code, Teach_Period).then(data=>{
                 res.json(getInsideData(data))
             }).catch(err=>{
                 res.send('NOTOKAY')
              })
        }else{
            res.send('N/A')
        }

    })

    app.post('/downloadResult',authenticationToken,(req, res)=>{
        Stud.getAllData(req.body.Unit_Code).then(data=>{
            studSPE.getResult(req.body.Unit_Code, Teach_Period).then(data1=>{
                let counter = 0
                
                for(let i=0; i<data.length;i++){
                    data[i].Final_Result = 0
                    counter = 0
                    for(let j=0;j<data1.length;j++){
                        if(data[i].Person_ID === data1[j].Person_ID){
                            data[i] = {...data[i], [data1[j].Title]: data1[j].Score}
                            counter++
                            data[i].Final_Result = data[i].Final_Result +  Number(data1[j].Score)
                        
                        }
                    }
                    data[i].Final_Result = data[i].Final_Result / counter
                    const temp = data[i].Final_Result * (req.body.Percent/100)
                    data[i].Final_Result = temp.toFixed(2)
                }
                res.json([data, `Result of ${req.body.Unit_Code} (${Teach_Period})`])
            }).catch(err=>{
                res.send('NOTOKAY')
            })
        }).catch(err=>{
            res.send('NOTOKAY')
        })
    })



}

const getInsideData =(Obj)=>{
    let question = []
    let counter = 0
    let result = []
    let counter1 = 0
    let counterResult = 0
    let devider = 0

    for(let i=0; i<Obj.length;i++){

        let answer = []
        counter = 0
        if(Obj[i].Question_1 !== 'N/A'){
            question[counter] = Obj[i].Question_1
            answer[counter] = Obj[i].Answer_1
            counter++
            devider++
            if(Obj[i].Answer_1 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_2 !== 'N/A'){
            question[counter] = Obj[i].Question_2
            answer[counter] = Obj[i].Answer_2
            counter++
            devider++
            if(Obj[i].Answer_2 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_3 !== 'N/A'){
            question[counter] = Obj[i].Question_3
            answer[counter] = Obj[i].Answer_3
            counter++
            devider++
            if(Obj[i].Answer_3 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_4 !== 'N/A'){
            question[counter] = Obj[i].Question_4
            answer[counter] = Obj[i].Answer_4
            counter++
            devider++
            if(Obj[i].Answer_4 === ''){
                counterResult++
            }
        }
        if(Obj[i].Question_5 !== 'N/A'){
            question[counter] = Obj[i].Question_5
            answer[counter] = Obj[i].Answer_5
            counter++
            devider++
            if(Obj[i].Answer_5 === ''){
                counterResult++
            }
        }
        devider++
        if(Obj[i].Comments === ''){
            counterResult++
        }
        result.push({name:`${Obj[i].Given_Names} (${Obj[i].Teamate_ID})`,Teamate_ID: Obj[i].Teamate_ID, Answer: answer , Comments: Obj[i].Comments})
    }
        const percent = ((devider - counterResult)/devider) * 100
        return [result, question, percent.toFixed(2)]
}