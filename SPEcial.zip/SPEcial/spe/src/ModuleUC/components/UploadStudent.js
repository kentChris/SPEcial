import React from 'react'
import * as XLSX from 'xlsx'
import axios from 'axios'


function UploadStudent({unit, period}) {  
    const [data, setData] = React.useState([])
    const [people, setPeople] = React.useState({
        Student_ID:'',
        Email:'',
        Title:'',
        Team_ID:'',
        Surname:'',
        Given_Name:'',
        Teach_Period:period,
        Unit_Code:unit
    })
    const [modal0, setModal0] =React.useState(false)
    const [modal1, setModal1] =React.useState(false)
    const [modal2, setModal2] =React.useState(false)
    const [modal3, setModal3] =React.useState(false)
    const [fileName, setFileName] = React.useState('Upload Excel File...')

     const readExcel = (file)=>{
     return new Promise((resolve, reject)=>{
       const fileReader = new FileReader();
       fileReader.readAsArrayBuffer(file);

       fileReader.onload=(e)=>{
        const bufferArray = e.target.result;

        const wb = XLSX.read(bufferArray,{type:'buffer'});

        const wsname= wb.SheetNames[0];

        const ws = wb.Sheets[wsname];
         
        const data = XLSX.utils.sheet_to_json(ws)
        resolve(data);
       }

       fileReader.onerror=(err)=>{
          reject(err)
       }
     })
  }

    
    const fileChange = (e) =>{
        setFileName(e.target.files[0].name)
        readExcel(e.target.files[0]).then(data=>{
            setData(data)
        }).catch(err=>{
            setModal1(true)
        })
    }

    function sendFile(){
        let token = ''
        token = localStorage.getItem('token')
        
        axios.post('http://localhost:5000/addStudents',{
            auth:'Bearer '+token,
            student: data,
            Teach_Period: period,
            Unit_Code: unit
        }).then(res=>{
            if(res.data === 'OKAY'){
                setModal0(true)
            }else{
               setModal1(true) 
            }
        }).catch(err=>{
            setModal1(true)
        })
    }

    React.useEffect(()=>{
        setTimeout(()=>{
            setModal1(false)
        },3000)
    },[modal1])


    React.useEffect(()=>{
        setTimeout(()=>{
            setModal0(false)
        },3000)
    },[modal0])

    React.useEffect(()=>{
        setTimeout(()=>{
            setModal2(false)
        },3000)
    },[modal2])


    React.useEffect(()=>{
        setTimeout(()=>{
            setModal3(false)
        },3000)
    },[modal3])

    const onChangeUser = (e) =>{
        const name= e.target.name
        const value= e.target.value
        setPeople({...people, [name]:value})
    }

    const submitUser = () =>{
        let token = ''
        token = localStorage.getItem('token')
        axios.post('http://localhost:5000/submitStudent',{
            auth:'Bearer '+token,
            student: people
        }).then(res=>{
            if(res.data==='NOTOKAY'){
                setModal3(true)
            }else{
                setModal2(true)
            }
        }).catch(err=>{
            console.log(err)
            setModal3(true)
        })
    }


    return <>
        <div className='addStudent'>
                <h1 style={{paddingLeft:'3%', paddingTop:'2%', color:'#0070A8', fontSize:'26.25px'}}>Input Student</h1>
                <div className='mainAddStudent'>
                    <div className='grid1'>
                            <input type='text' value={fileName} className='fileName' readOnly></input>
                            <div className='grid2'>
                                <label htmlFor="file" className="files">Choose File To Upload</label>
                                <input id='file' style={{visibility:'hidden'}} type="file" accept='.xlsx' onChange={(e)=>fileChange(e)} />
                            </div>
                            <button className='submitFiles' onClick={()=>sendFile()}>Submit</button>
                    </div>
                    {modal0 && <p style={{color:'red',marginLeft:'47%'}}>User Added</p>}
                    {modal1 && <p style={{color:'red', marginLeft:'40%'}}>There is Something wrong with the excel file</p>}
                    <h3 style={{marginLeft:'50%', fontWeight:'lighter'}}>Or</h3>
                    <h3 style={{marginLeft:'1.3%', marginBottom:'0'}}>Fill in Student Information</h3>
                    <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Student ID</h4>
                    <input type='text' name='Student_ID' onChange={(e)=>onChangeUser(e)} value={people.Student_ID} style={{width:'20%', border:'0px solid', height:'2em', marginLeft:'3%'}}  />
                    <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'5%', border:'0px solid'}}>Email</h4>
                    <input type='text' name='Email' value={people.Email} onChange={(e)=>onChangeUser(e)} style={{width:'55%', border:'0px solid', height:'2em',  marginLeft:'3%'}}/>
                    <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Title</h4>
                    <select name='Title' onChange={(e)=>onChangeUser(e)} style={{width:'20%', border:'0px solid', marginLeft:'6.2%', height:'2.2em'}} name='Title'>
                        <option value='null'>Choose</option>
                        <option value='Mr'>Mr.</option>
                        <option value='Mrs'>Mrs.</option>
                    </select>
                    <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'5%'}}>Team ID</h4>
                    <input type='text' name='Team_ID' onChange={(e)=>onChangeUser(e)} value={people.Team_ID} style={{width:'20%', border:'0px solid', height:'2em', marginLeft:'1.8%'}}  />
                    <div>
                        <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Surname</h4>
                        <input name='Surname' type='text' onChange={(e)=>onChangeUser(e)} value={people.Surname} style={{width:'86%', border:'0px solid', height:'2em', marginLeft:'4%'}}  />
                        <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Given Names</h4>
                        <input name='Given_Name' value={people.Given_Name} onChange={(e)=>onChangeUser(e)} type='text' style={{width:'86%', border:'0px solid', height:'2em', marginLeft:'1.5%'}}  />
                    </div>
                        <button className='submitUser' onClick={submitUser}>Submit</button>
                        {modal2 && <p style={{color:'red',marginLeft:'50%', paddingBottom:'2%'}}>User Added</p>}
                        {modal3 && <p style={{color:'red', marginLeft:'45%', paddingBottom:'2%'}}>There is Something wrong</p>}
                    
                </div>
        </div>
    </>
}

export default UploadStudent

// function onChange(value) {
//   console.log(`selected ${value}`);
// }

// function onBlur() {
//   console.log('blur');
// }

// function onFocus() {
//   console.log('focus');
// }

// function onSearch(val) {
//   console.log('search:', val);
// }

// ReactDOM.render(
//   <Select
//     showSearch
//     style={{ width: 200 }}
//     placeholder="Select a person"
//     optionFilterProp="children"
//     onChange={onChange}
//     onFocus={onFocus}
//     onBlur={onBlur}
//     onSearch={onSearch}
//     filterOption={(input, option) =>
//       option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
//     }
//   >
//     <Option value="jack">Jack</Option>
//     <Option value="lucy">Lucy</Option>
//     <Option value="tom">Tom</Option>
//   </Select>,
//   mountNode,
// );