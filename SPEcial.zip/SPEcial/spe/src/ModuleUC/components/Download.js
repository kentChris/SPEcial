import React from 'react'
import axios from 'axios'
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import {Input} from 'antd'

function Download({unit}) {
    const [percent, setPercent] = React.useState(0)
    const [modal, setModal] = React.useState(false)
    const [modal1, setModal1] = React.useState(false)

    const handleClick=()=>{
        setModal(true)
        let token=''
        token = localStorage.getItem('token')
        axios.post('http://localhost:5000/downloadResult',{
            auth:'Bearer '+ token,
            Unit_Code: unit,
            Percent: percent
        }).then(res=>{
            exportToCSV(res.data[0], res.data[1])
            setModal(false)
        }).catch(err=>{
            setModal(false)
            setModal1(true)
            setTimeout(() => {
                setModal1(false)
            }, 3000);
        })
    }

    const onChangeUser = (e) =>{
        const value= e.target.value
        setPercent(value)
    }

    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = '.xlsx';
    const exportToCSV = (csvData, fileName) => {

        const ws = XLSX.utils.json_to_sheet(csvData);

        const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };

        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });

        const data = new Blob([excelBuffer], {type: fileType});

        FileSaver.saveAs(data, fileName + fileExtension);
    }

    return <>
        <div className='addStudent'>
            <h1 style={{paddingLeft:'3%', paddingTop:'2%', color:'#0070A8', fontSize:'26.25px'}}>Download Result</h1>
            <div className='mainAddStudent'>
                <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Choose a final percentage for this module:  </h4>
                <Input type='text' suffix='%' onChange={(e)=>onChangeUser(e)} value={percent} style={{ border:'0px solid', height:'2em', marginLeft:'3%'}} />
                <button className='sendStudent' onClick={()=>handleClick()}>Download</button>
                {modal && <p style={{color:'red',fontSize:'20px', textAlign:'center'}}>Please Wait...</p>}
                {modal1 && <p style={{color:'red',fontSize:'20px', textAlign:'center'}}>There is something wrong</p>}
            </div>
        </div>
    </>
}

export default Download
