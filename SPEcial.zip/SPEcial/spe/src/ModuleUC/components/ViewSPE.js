import React from 'react'
import axios from 'axios'
import {Progress} from 'antd'


function ViewSPE({students, SPE, unit}) {

    const [student, setStudent] = React.useState('')
    const [spe, setSpe] = React.useState('')
    const [view, setView] = React.useState([])
    const [modal, setModal] = React.useState(false)
    const [indexx, setIndexx] = React.useState(0)

    const handleChange=(e)=>{
        const value =e.target.value
        setSpe(value)
    }

    const handleChange1=(e)=>{
        const value =e.target.value
        setStudent(value)
    }

    const handleClick =()=>{
        let token = ''
        token = localStorage.getItem('token')
        axios.post('http://localhost:5000/getSpeData',{
            auth:'Bearer '+ token,
            student: student,
            SPE: spe,
            Unit_Code: unit
        }).then(res=>{
            setView(res.data)
            setModal(true)
        }).catch(err=>{
            window.location.href='/'
        })
    }

    const handleChange2 =(e)=>{
        setIndexx(e.target.value)
    }

    return <>
        <div className='addStudent'>
            <h1 style={{paddingLeft:'3%', paddingTop:'2%', color:'#0070A8', fontSize:'26.25px'}}>View Self and Peer Evaluation</h1>
            <div className='mainAddStudent'>
                <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Choose a Student: </h4>
                <select style={{marginLeft:'0.5%', width:'40%', height:'2em'}} onChange={(e)=>handleChange1(e)}>
                    <option value=''>N/A</option>
                    {students.map((data, index)=>{
                        return(
                            <option key={index} style={{fontSize:'30px'}} value={data.Person_ID} >{data.Given_Names}  ({data.Person_ID}) {data.Team_ID}</option>
                        )         
                    })}
                </select>
                <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Choose a SPE Title: </h4>
                <select style={{marginLeft:'0.5%', width:'10%', height:'2em'}} onChange={(e)=>handleChange(e)}>
                    <option value=''>N/A</option>
                    {SPE.map((data, index)=>{
                        return(
                            <option key={index} style={{fontSize:'30px'}} value={data.Title} >{data.Title}</option>
                        )          
                    })}
                </select>
                <button className='sendStudent' onClick={()=>handleClick()} >Send</button>

                {modal && <div>
                    <h4 style={{fontWeight:'200', marginLeft:'2%', marginTop:'0'}}>Progress Bar: </h4>
                     <Progress
                    strokeColor={{
                    '0%': '#108ee9',
                     '100%': '#87d068',
                    }}
                    percent={view[2]}
                    style={{width:'94.5%', marginLeft:'2.5%'}}    
                    />
                   <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Choose the Teamate: </h4>
                    <select style={{marginLeft:'0.5%', width:'30%', height:'2em'}} onChange={(e)=>handleChange2(e)}>
                          {view[0].map((data, index)=>{
                              return(
                              <option key={index} style={{fontSize:'30px'}} value={index} >{data.name}</option>
                                     )         
                            })}
                    </select>
                    <div style={{paddingBottom:'2%'}}>
                    {view[1].map((data, index)=>{
                               return(
                                   <div key={index} style={{width:'93%', margin:'0 auto', backgroundColor:'white', marginTop:'2%'}}>
                                    <div style={{height:'0.8em', width:'100%', backgroundColor:'red'}}></div>
                                    <p style={{fontSize:'18px',marginLeft:'0.5%', display:'inline-block'}}>{`${index+1}. ${data}`}</p>
                                    <input type='text' value={view[0][indexx].Answer[index]} readOnly style={{marginLeft:'3%', width:'4em', height:'1.5em'}}></input>
                                    </div>
                                    )
                              })}
                        <div style={{width:'93%', margin:'0 auto', backgroundColor:'white', marginTop:'2%'}}>
                        <div style={{height:'0.8em', width:'100%', backgroundColor:'red'}}></div>
                        <p style={{fontSize:'18px', marginLeft:'0.5%'}}>Please Justify Your Answer</p>
                        <textarea value={view[0][indexx].Comments} readOnly style={{minWidth:'98%', maxWidth:'98%', marginLeft:'0.6%', minHeight:'7em', maxHeight:'7em'}}></textarea>
                        </div>
                    </div>
                </div>}
            </div>
        </div>
    </>
}

export default ViewSPE
