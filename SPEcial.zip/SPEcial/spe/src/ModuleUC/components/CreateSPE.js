import React from 'react'
import {Link} from 'react-router-dom'

function CreateSPE({unit}) {
    return <>
        <div className='createSPE'>
            <h1 style={{paddingLeft:'3%', paddingTop:'2%', color:'#0070A8', fontSize:'26.25px'}}>Create Self and Peer Evaluation</h1>
            <div className='createMainDiv'>
                <Link to={`/createSPE/${unit}`}> 
                <button className='createButton'>Create SPE</button>
                </Link>
                
            </div>
        </div>
    </>
}

export default CreateSPE
