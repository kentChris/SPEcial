import React from 'react'

import IMG from '../../module.jpeg'

function HeaderIMG({unit, name}) {
const date = new Date();
let Teach_Period = ''
if(date.getMonth() === 0 || date.getMonth() === 1 || date.getMonth() === 2 || date.getMonth() === 3){
    Teach_Period = 'S1'+ date.getFullYear()
}else if(date.getMonth() === 4 || date.getMonth() === 5 || date.getMonth() === 6 || date.getMonth() === 7){
    Teach_Period = 'S2'+date.getFullYear()
}else{
    Teach_Period = 'S3'+date.getFullYear()
}
    return <>
        <div>
            <img style={{width:'100%'}} src={IMG} alt='headerImage'></img>
            <h1 style={{backgroundColor:'rgb(0,0,0, 0.7)', color:'white', fontSize:'1.3em', fontWeight:'lighter',padding:'10px 10px 10px 10px', width:'max-content'
                        , position:'absolute', marginLeft:'7%', marginTop:'-7%'}}>{unit} {name} {`(${Teach_Period})`}</h1>
        </div>
    </>
}

export default HeaderIMG
