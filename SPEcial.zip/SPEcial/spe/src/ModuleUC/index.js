import React from 'react'
import {useParams} from 'react-router-dom'
import App from './app'
function Index() {

    const {unit} = useParams()
    return (
        <div>
            <App unit={unit}/>
        </div>
    )
}

export default Index
