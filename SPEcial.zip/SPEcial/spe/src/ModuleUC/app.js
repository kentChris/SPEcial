import React from 'react'
import axios from 'axios'

import Header from '../dashboard/components/Header'
import Modal from '../dashboard/components/Modal'
import HeaderIMG from './components/HeaderIMG'
import Create from './components/CreateSPE'
import './index.css'
import Upload from './components/UploadStudent'
import {MdOutlineEmail} from 'react-icons/md'
import ViewSPE from './components/ViewSPE'
import Download from './components/Download'
import Footer from '../dashboard/components/Footer'

export default class App extends React.Component {
    
    state = {
        loading: true,
        data: null,
        isAdmin: false,
    }

    componentDidMount() {
     let token = ''
     token = localStorage.getItem('token')
     axios.post('http://localhost:5000/moduleData',{
         auth: 'Bearer '+token,
         Teach_Period: 'JA2021',
         Unit_Code: this.props.unit
     }).then(res=>{
         if(res.data === 'NOTOKAY'){
                window.location.href = '/'
            }
            if(res.data[0].id === 'admin'){
                this.setState({data: res.data, loading: false, isAdmin: true})
            }else{
                this.setState({data: res.data, loading: false, isAdmin:false})
            }
     }).catch(
            ()=>window.location.href = '/'
        )
    }

    render(){
        return <div>
            {this.state.loading ? <Modal /> : 
            <div>
                <Header isAdmin={this.state.isAdmin} ID={this.state.data[0].user} />
                <div style={{width:'101%', marginLeft:'-0.5%'}}>
                    <HeaderIMG unit={this.props.unit} name={this.state.data[1].Name}/>
                    <div className='mainBody'>
                        <div className='body1'>
                            {this.state.isAdmin && <Upload unit={this.props.unit} period={'JA2021'} />}
                            <Create unit={this.props.unit}/>
                            <ViewSPE students={this.state.data[2]} SPE={this.state.data[3]} unit={this.props.unit}/>
                            <Download unit={this.props.unit}/>
                        </div>
                        <div className='body2'>
                            {this.state.isAdmin? 
                                <div className='contact'>
                                    <p style={{fontSize:'18.75px', color:'#373A3C', fontWeight:'bold'}}>UC Contacts</p>
                                    <img style={{marginLeft:'15%'}} src='https://secure.gravatar.com/avatar/1d8db3a82aec8882fe668501ca25a6c0?s=100&d=mm'></img>
                                    <p style={{fontSize:'16px', textAlign:'center'}}>{this.state.data[1].UC_Name}</p>
                                    <a style={{fontSize:'18px', textAlign:'center'}} href ={`mailto: ${this.state.data[1].Email}`}>{<MdOutlineEmail style={{color:'red'}}/>}{this.state.data[1].Email}</a>
                                </div> :
                                <div className='contact'>
                                    <p style={{fontSize:'18.75px', color:'#373A3C', fontWeight:'bold'}}>Admin Contacts</p>
                                    <img style={{marginLeft:'15%'}} src='https://secure.gravatar.com/avatar/1d8db3a82aec8882fe668501ca25a6c0?s=100&d=mm'></img>
                                    <p style={{fontSize:'16px', textAlign:'center'}}>Admin</p>
                                    <a style={{fontSize:'18px', textAlign:'center'}} href ={`mailto: admin@gmail.com`}>{<MdOutlineEmail style={{color:'red'}}/>}admin@gmial.com</a>
                                </div>}
                        </div>
                    </div>
                </div>
                 <Footer />
            </div>}

        </div>;
    }
}