import React from 'react'
import Email from './components/Email'

const SignIn = () =>{
    return <>
    <div>
        <img className='background-image' src='https://therightustorage.blob.core.windows.net/assets/University/A017_Murdoch_01.jpg' alt='background' />

        <div className='sign-in'>
            <Email />
        </div>
    </div>
    </>
}

export default SignIn