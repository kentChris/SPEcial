import React,{useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import '../index.css'

function Register() {
  
    const [email, setEmail]= useState('')
    const [isEmail, setIsEmail] = useState(false)
    
    const Send = () =>{
        axios.post(`http://localhost:5000/email?email=${email}`).then((res)=>{
            if(res.data === 'Sent'){
                setIsEmail(true) 
            }
        })
        .catch(()=>setIsEmail(false))
    }

    return (
         <div>
            <img style={{width:'168px', height:'36px', paddingBottom:'16px'}} className='logo' src='https://aadcdn.msauthimages.net/81d6b03a-6qgi2kc8brdyt5zovsmn3p1x0-t-v5-1-hbz0hxnhl4/logintenantbranding/0/bannerlogo?ts=637075786552747320' alt='logo' />
            <h2 style={{marginTop:'0em'}}>Email</h2>

            {isEmail && <p>Please open your email</p> }
            

            <input type='email' name='email'
            placeholder='Email' className='username-input'
            onChange={(e)=>setEmail(e.target.value)}/>
            <hr className='line'></hr>


            <div style={{float:'right'}} >  
                    <Link to='/' className='back-button'>Back</Link>
                    <button className='next-button' style={{paddingLeft:'32px', paddingRight:'32px'}} onClick={Send}>Send</button>  
            </div>

            <div className='footer'>
             <p>Please enter email to reset your password</p>
            </div>
        </div>
    )
}

export default Register
