import React from 'react'
import { useState, useEffect} from 'react'
import {Link} from 'react-router-dom'
import axios from 'axios'
//CSS
import '../index.css'

function Username() {
    const [usernameLog, setUsernameLog] = useState(true)
    const [people, setPeople] = useState({username:'', password:''})
    const [modal, setModal] = useState(false)


    const signIn = () =>{
        axios.post(`http://localhost:5000/login?username=${people.username}&password=${people.password}`).then((res) =>{
        if(res.data !== 'Unsucessful'){
            localStorage.setItem('token',res.data.accessToken)
            window.location.href='/dashboard'
        }else{
            setModal(true);
        }
    }).catch((error)=>{
        console.log(error)
    })
    }

    useEffect(() => {
        setTimeout(()=>{
            setModal(false)
        },3000)
    }, [modal])
    

    const handleChange = (e) =>{
        const name= e.target.name
        const value=e.target.value
        setPeople({...people, [name]:value})
    }

    const changeButton = () =>{
        if(usernameLog === false){
            setPeople({...people, username:'', password:''})
        }
        setUsernameLog(!usernameLog)
    }


    return (
        <div>
            <img style={{width:'168px', height:'36px', paddingBottom:'16px'}} className='logo' src='https://aadcdn.msauthimages.net/81d6b03a-6qgi2kc8brdyt5zovsmn3p1x0-t-v5-1-hbz0hxnhl4/logintenantbranding/0/bannerlogo?ts=637075786552747320' alt='logo' />
            <h2 style={{marginTop:'0em'}}>{usernameLog ? 'Sign in':'Password'}</h2>

            <p>Your organisational policy requires you to sign in again after a certain period of time.</p>

            {modal && <p style={{color:'red'}}>Your account or password is incorrect.</p>}

            <input type={usernameLog? 'text':'password'} name={usernameLog?'username':'password'} 
            placeholder={usernameLog? 'UC ID' : 'Password'} className='username-input'
            value={usernameLog ? people.username : people.password} 
            onChange={handleChange}/>
            <hr className='line'></hr>

            {usernameLog ?
            <Link style={{textDecoration:'none', paddingBottom:'12px', color:'blue'}} to='/email'><p>Forget Password</p></Link> :
            <Link style={{textDecoration:'none', paddingBottom:'12px', color:'blue'}} to='/email'><p>Forget Password</p></Link>}
    
            <div style={{float:'right'}} >
                {usernameLog ? 
                <button className='next-button' onClick={changeButton}>Next</button> :
                <div>
                    <button className='back-button' onClick={changeButton}>Back</button>
                    <button className='next-button' onClick= {signIn}style={{paddingLeft:'32px', paddingRight:'32px'}}>Sign in</button>
                </div>}
            </div>

            <div className='footer'>
             <p>Please enter the UC ID in form of<br /> Unit Coordinator Id (eg. UC123456)</p>
            </div>
        </div>
    )
}

export default Username
