import React, {useState} from 'react'

//Pages
import Username from './components/Username'


const SignIn = () =>{
    
    return <>
    <div>
        <img className='background-image' src='https://therightustorage.blob.core.windows.net/assets/University/A017_Murdoch_01.jpg' alt='background' />

        <div className='sign-in'>
            <Username />
        </div>
    </div>
    </>
}

export default SignIn