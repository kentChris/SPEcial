import React from 'react'
import axios from 'axios'

import Loading from '../dashboard/components/Modal'
import Header from './Components/Header'
import IMGHeader from '../ModuleUC/components/HeaderIMG'
import {MdOutlineEmail} from 'react-icons/md'
import Footer from '../dashboard/components/Footer'
import {Progress} from 'antd' 


import './index.css'



export default class App extends React.Component {
    
    state = {
        loading: true,
        data: null,
        index: 0,
        modal: false
    }

    componentDidMount() {
     axios.post('http://localhost:5000/SPE',{
         auth:'Bearer '+ this.props.token
     }).then(res=>{
        if(res.data === 'NOTOKAY'){
            window.location.href = 'http://google.com'
        }
        this.setState({loading: false, data: res.data, index:0, modal:false})
     }).catch(err=>{
        window.location.href = 'http://google.com'
     })
    }

    handleChange=(e, index)=>{
        const value = e.target.value
        let tempState = this.state
        tempState.data[3][this.state.index].Answer[index] = value
        this.setState(tempState)

    }


    handleChange1=(e)=>{
        const value = e.target.value
        let tempState = this.state
        tempState.data[3][this.state.index].Comments = value
        this.setState(tempState)
    }

    handleOnClick=(index)=>{
        let tempState = this.state
        tempState.index = index 
        this.setState(tempState)
    }

    handleOnClick1=()=>{
        axios.post('http://localhost:5000/saveSPE',{
            auth: 'Bearer '+ this.props.token,
            Obj: this.state.data[3]
        }).then(res=>{
            if(res.data === 'NOTOKAY'){
                console.log('error')
            }else{
                window.location.href = `http://localhost:3000/SPE/${this.props.token}`
            }
        }).catch(err=>{
            window.location.href = `http://localhost:3000/SPE/${this.props.token}`
        })
    }

    

    render(){
        return <div>
            {this.state.loading ? <Loading /> : <div>
                <Header id={this.state.data[0].Person_ID}/>
                <div style={{marginLeft:'-0.5%', width:'101%'}}>
                <IMGHeader unit={this.state.data[0].Unit_Code} name={this.state.data[1][0].Name}/>
                </div>
                <div className='dashboard' style={{marginTop:'-0.3%', minHeight:'55em'}}>
                    <div className='bodyD1' >
                        <h1 style={{fontSize:'30px', color:'#373A3C', fontWeight:'bold', marginLeft:'3%'}}>{this.state.data[0].Title}</h1>
                        <h2 style={{fontSize:'30px', color:'#373A3C', fontWeight:'bold', marginLeft:'3%', marginTop:'0'}}>Evaluating for :{this.state.data[3][this.state.index].name}</h2>
                        <p style={{fontSize:'16px', marginLeft:'3%'}}>Note: Answer in form of 1-5. 1 = 'Very Bad' to 5 = 'Excellent'</p>
                        <p style={{fontSize:'16px', marginLeft:'3%', color:'red'}}>{this.state.data[2]}</p>
                         <Progress
                            strokeColor={{
                            '0%': '#108ee9',
                            '100%': '#87d068',
                            }}
                            percent={this.state.data[5]}
                            style={{width:'95%', marginLeft:'2.5%'}}    
                            />
                            {this.state.data[4].map((data, index)=>{
                               return(
                                   <div key={index} style={{width:'93%', margin:'0 auto', backgroundColor:'white', marginTop:'2%'}}>
                                    <div style={{height:'0.8em', width:'100%', backgroundColor:'red'}}></div>
                                    <p style={{fontSize:'18px',marginLeft:'0.5%', display:'inline-block'}}>{`${index+1}. ${data}`}</p>
                                    <input type='text' value={this.state.data[3][this.state.index].Answer[index]} onChange={(e)=>this.handleChange(e, index)} style={{marginLeft:'3%', width:'4em', height:'1.5em'}}></input>
                                    </div>
                                    )
                              })}
                        <div style={{width:'93%', margin:'0 auto', backgroundColor:'white', marginTop:'2%'}}>
                        <div style={{height:'0.8em', width:'100%', backgroundColor:'red'}}></div>
                        <p style={{fontSize:'18px', marginLeft:'0.5%'}}>Please Justify Your Answer</p>
                        <textarea value={this.state.data[3][this.state.index].Comments} onChange={(e)=>this.handleChange1(e)} style={{minWidth:'98%', maxWidth:'98%', marginLeft:'0.6%', minHeight:'7em', maxHeight:'7em'}}></textarea>
                        </div>


                    </div>
                    <div className='bodyD2'>
                        <div className='contact' style={{margin:'0 auto', marginTop:'10%'}}>
                            <p style={{fontSize:'18.75px', color:'#373A3C', fontWeight:'bold'}}>UC Contacts</p>
                            <img style={{marginLeft:'15%'}} src='https://secure.gravatar.com/avatar/1d8db3a82aec8882fe668501ca25a6c0?s=100&d=mm'></img>
                            <p style={{fontSize:'16px', textAlign:'center'}}>{this.state.data[1][0].UC_Name}</p>
                            <a style={{fontSize:'18px', textAlign:'center'}} href ={`mailto: ${this.state.data[1][0].Email}`}>{<MdOutlineEmail style={{color:'red'}}/>}{this.state.data[1][0].Email}</a>
                        </div>
                        <p onClick={this.handleOnClick1} style={{color:'blue', fontSize:'18px', marginLeft:'13%'}}>Save Changes...</p>
                        {this.state.modal && <p style={{marginLeft:'13%',fontSize:'16.78px', color:'red'}}>Saved...</p>}
                        <div style={{backgroundColor:'white', width:'80%',margin:'0 auto', marginTop:'10%', paddingBottom:'5%'}}>
                        {this.state.data[3].map((data, index)=>{
                            return(
                                <div key={index}>
                                    <button onClick={()=>this.handleOnClick(index)} style={{backgroundColor:'white', border:'2px solid red', fontSize:'20px', width:'95%', marginLeft:'3%', marginTop:'5%'}}>{data.name}</button>
                                </div>
                            )
                        })}
                        </div>
                    </div>
                </div>
                <Footer />
            </div> }
        </div>;
    }
}