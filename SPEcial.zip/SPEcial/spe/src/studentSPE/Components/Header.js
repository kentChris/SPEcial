import React from 'react'
import {Link} from 'react-router-dom'
import '../index.css'
import {AiFillHome, AiOutlineUserAdd} from 'react-icons/ai'
import {GoDiffAdded} from 'react-icons/go'
import {FaUserCircle} from 'react-icons/fa'

function Header({id}) {
    return (
        <div className='header' className='Header'>
            <img style={{width:'168px', height:'18px', marginTop:'8%', marginLeft:'5%'}} className='logo' src='https://moodleprod.murdoch.edu.au/pluginfile.php/1/core_admin/logocompact/300x300/1632348458/myMurdochLearning-264x27.png' alt='logo' />
            <p style={{color:'white', gridColumnStart:'5'}}>{id}<FaUserCircle style={{color:'white', marginLeft:'5px'}}/></p>
        </div>
    )
}

export default Header


