import React from 'react'
import {useParams} from 'react-router-dom'
import App from './app'
function Index() {

    const {token} = useParams()
    return (
        <div>
            <App token={token} />
        </div>
    )
}

export default Index
