import React from 'react'
import axios from 'axios'
import Footer from '../../dashboard/components/Footer'


function MainBody({unit}) {
    const [spe, setSPE] = React.useState({
        Title:'',
        Date:'',
        Time:'',
        Note:'',
    })

    const [question, setQuestion] = React.useState([])

    const addQuestion = () =>{
        if(question.length < 5)
        setQuestion([...question,''])
    }

    const handleChange =(e,index)=>{
        const value = e.target.value
        const list = [...question]
        list[index] = value
        setQuestion(list)
    }

    const changeData = (e) =>{
        const name = e.target.name  
        const value = e.target.value
        setSPE({...spe, [name]:value})
    }

    const removeQuestion = (index) =>{
        const list =  [...question]
        list.splice(index,1)
        setQuestion(list)
    }

    const back = () =>{
        window.location.href = `/module/${unit}`
    }

    const submit = () =>{
        let token = ''
        token = localStorage.getItem('token')
        axios.post('http://localhost:5000/createSPE',{
            auth:'Bearer '+ token,
            SPE: spe,
            Question: question,
            Unit_Code: unit
        }).then(res=>{
            if(res.data === 'NOTOKAY'){
                window.location.href = `/module/${unit}`
            }else{
                window.location.href = `/module/${unit}`
            }
        }).catch(err=>{
            window.location.href = `/module/${unit}`
        })
    }
    
    return <>
        <div style={{backgroundColor:'#eff3f5', width:'101%', marginLeft:'-0.5%', marginTop:'-0.2%', minHeight:'50%', height:'42.1em'}}>
        <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Title</h4>
        <input type='text' onChange={e=>changeData(e)} value={spe.Title} name='Title' style={{width:'70%', height:'2em',border:'0px solid', marginLeft:'3%', backgroundColor:'white'}}  />
        <br /> 
        <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%', marginTop:'0'}}>Date</h4>
        <input type='Date' onChange={e=>changeData(e)} value={spe.Date}  name='Date' style={{width:'10%', height:'2em',border:'0px solid', marginLeft:'3%', backgroundColor:'white'}}  /> 
        <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%', marginTop:'0'}}>Time</h4>
        <input type='time' onChange={e=>changeData(e)} value={spe.Time} name='Time' style={{width:'10%', height:'2em',border:'0px solid', marginLeft:'3%', backgroundColor:'white'}}  /> 
        <br />
         <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%', marginTop:'0', marginBottom:'0'}}>Note</h4>
         <br />
        <textarea onChange={(e)=>changeData(e)} value={spe.Note} style={{marginLeft:'2%', minWidth:'74.7%', minHeight:'5em'}} name='Note' >
        </textarea>
        {question.map((evaluation, index)=>{
            return (
                <div key={index}>
                <h4 style={{display:'inline-block', fontWeight:'200', marginLeft:'2%'}}>Question {index+1}</h4>
                <input type='text' value={evaluation} onChange={e=>handleChange(e, index)} style={{width:'60.6%', height:'2em',border:'0px solid', marginLeft:'3%', backgroundColor:'white'}}  />
                <button onClick={()=>removeQuestion(index)} className='removeButton'>Remove</button>
                </div>    
            )
        })}
        <br />
        <p style={{marginLeft:'2%', textDecoration:'underline', display:'inline-block', color:'blue'}} onClick={addQuestion} >+ Add Question</p>
        <p style={{marginLeft:'5%', textDecoration:'underline', display:'inline-block', color:'blue'}} onClick={back} >+ Exit without Changes</p>
        <button className='removeButton' style={{marginLeft:'5%'}} onClick={submit}>Submit</button>
        </div>
        <Footer />
    </>
}

export default MainBody
