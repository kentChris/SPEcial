import React from 'react'
import axios from 'axios'

import Header from '../dashboard/components/Header'
import Modal from '../dashboard/components/Modal'
import HeaderIMG from '../ModuleUC/components/HeaderIMG'
import MainBody from './components/MainBody'

import './index.css'



export default class App extends React.Component {
    
    state = {
        loading: true,
        data: null,
        isAdmin: false,
    }

    componentDidMount() {
     let token = ''
     token = localStorage.getItem('token')
     axios.post('http://localhost:5000/moduleData',{
         auth: 'Bearer '+token,
         Teach_Period: 'JA2021',
         Unit_Code: this.props.unit
     }).then(res=>{
         if(res.data === 'NOTOKAY'){
                window.location.href = '/'
            }
            if(res.data[0].id === 'admin'){
                this.setState({data: res.data, loading: false, isAdmin: true})
            }else{
                this.setState({data: res.data, loading: false, isAdmin:false})
            }
     }).catch(
            ()=>window.location.href = '/'
        )
    }

    render(){
        return <div>
            {this.state.loading ? <Modal /> : 
            <div>
                <Header isAdmin={this.state.isAdmin} ID={this.state.data[0].user} />
                <div style={{width:'101%', marginLeft:'-0.5%'}}>
                    <HeaderIMG unit={this.props.unit} name={this.state.data[1].Name}/>
                </div>
                <MainBody unit={this.props.unit}/>
                
            
            </div>}

        </div>;
    }
}