import React from 'react'
import '../index.css'

function Footer() {
    return (
        <div>
            <div className='error-footer'>
            
            </div>
        </div>
        
    )
}

export default Footer
