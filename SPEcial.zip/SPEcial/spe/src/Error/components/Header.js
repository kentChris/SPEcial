import React from 'react'
import '../index.css'

function Header() {
    return <>
        <div className='error-header'>
            <img src='https://static.murdoch.edu.au/precedent/images/murdoch-logo-hoz-white.svg' style={{width:'9%', height:'6%', marginLeft:'0.5%', marginTop:'0.5%'}}alt='logo' />
            <hr className='line'></hr>
        </div>
    </>
}

export default Header
