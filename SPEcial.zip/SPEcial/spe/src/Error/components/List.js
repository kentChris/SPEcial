import React from 'react'
import '../index.css'

function List() {
    return <div className='list-div'>
        <h1 className='list-h1'>We will be back shortly...</h1>
        <p className='list-p'>We're currently working behind the scenes to improve the SPEcial website. We apologise for any inconvenience.</p>
        <p className='list-p'>In the meantime, you may find the following services useful:</p>
        <ul>
            <li>
                <p className='list-p'>
                    <a className='list-a' href='/'>Sign in</a>
                    &nbsp; - Registration can be accessed directly via the Class Sign-up page.
                </p>
            </li>
            <li>
                <p className='list-p'>
                    <a className='list-a' href='/dashboard'>Dashboard</a>
                    &nbsp; - Registration can be accessed directly via the Class Sign-up page.
                </p>
            </li>
            <li>
                <p className='list-p'>
                    <a className='list-a' href='/dashboard'>Dashboard</a>
                    &nbsp; - Registration can be accessed directly via the Class Sign-up page.
                </p>
            </li>
             <li>
                <p className='list-p'>
                    <a className='list-a' href='/dashboard'>Dashboard</a>
                    &nbsp; - Registration can be accessed directly via the Class Sign-up page.
                </p>
            </li>
             <li>
                <p className='list-p'>
                    <a className='list-a' href='/dashboard'>Dashboard</a>
                    &nbsp; - Registration can be accessed directly via the Class Sign-up page.
                </p>
            </li>
        </ul>
    </div>
}

export default List
