import React from 'react'
import Header from './components/Header'
import List from './components/List'
import Footer from './components/Footer'


function index() {
    return (
        <div>
            <Header />
            <img src='https://static.murdoch.edu.au/precedent/error-pages/503.jpg' alt='university' 
            style={{marginLeft:'-0.5%', maxWidth:'101%', height:'auto', marginBottom:'3%'}}/>
            <List />
            <Footer />
        </div>
    )
}

export default index
