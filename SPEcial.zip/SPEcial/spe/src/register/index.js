import React from 'react'
import Register from './components/Register'

function index() {
    return (
      <div>
        <img className='background-image' src='https://therightustorage.blob.core.windows.net/assets/University/A017_Murdoch_01.jpg' alt='background' />

        <div className='sign-in'>
            <Register />
        </div>
    </div>
    )
}

export default index
