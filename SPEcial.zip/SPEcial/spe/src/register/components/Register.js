import React,{useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import '../index.css'

function Register() {
    const [isNext, setIsNext] = useState(true)
    const [modal, setModal] = useState(false)
    let token = ''
    token = localStorage.getItem('token')
    const [people, setPeople] = useState({
        auth:'Bearer '+token,
        UC_ID:'',
        password:'',
        Email:'',
        UC_Name:'',
        Image:'',
    })

    useEffect(()=>{
        setTimeout(() => {
            setModal(false)
        }, 3000);
    },[modal])

    const changeButton = () =>{
        setIsNext(!isNext)
    }

    const handleChange = (e) =>{
        const name = e.target.name
        const value = e.target.value
        setPeople({...people, [name]:value})
    }
    
    const register = () =>{
        axios.post('http://localhost:5000/register',{
        auth: people.auth,
        UC_ID:people.UC_ID,
        password:people.password,
        Email:people.Email,
        UC_Name:people.UC_Name,
        Image:people.Image,
        }).then((res)=>{
            if(res.data === 'Succesful'){
                window.location.href='/dashboard'
            }else{
                setModal(true)
            }
        }).catch(()=>{
            setModal()
        })
    }

    return (
         <div>
            <img style={{width:'168px', height:'36px', paddingBottom:'16px'}} className='logo' src='https://aadcdn.msauthimages.net/81d6b03a-6qgi2kc8brdyt5zovsmn3p1x0-t-v5-1-hbz0hxnhl4/logintenantbranding/0/bannerlogo?ts=637075786552747320' alt='logo' />
            <h2 style={{marginTop:'0em'}}>Register</h2>

            <p>Register a new Unit Coordinator.</p>
            {modal && <p style={{color:'red'}}>UC ID has already been used</p>}
            

            <input type='text' name={isNext ?'UC_ID':'Image'}
            placeholder={isNext ? 'UC_ID': 'Image Link'} className='username-input'
            value={isNext? people.UC_ID: people.Image} onChange={handleChange}/>
            <hr className='line'></hr>

            {isNext && <div> <input type={isNext && 'password'} name={isNext && 'password'}
            placeholder={isNext? 'Password':'Teach Period'} className='username-input' 
            value={isNext? people.password : people.Teach_Period} onChange={handleChange}/>
            <hr className='line'></hr></div>}

            {isNext && <div><input type='text' name={isNext && 'Email'}
            placeholder={isNext &&'Email'} className='username-input'
            value={isNext&& people.Email} onChange={handleChange}/>
            <hr className='line'></hr></div>}

            {isNext && <div> <input type='text' name={isNext && 'UC_Name'} 
            placeholder={isNext && 'UC name'} className='username-input'
            value={isNext&& people.UC_Name } onChange={handleChange}/></div>}
            
            {isNext && <hr className='line'></hr>}

            <p>
                 <Link style={{textDecoration:'none', paddingBottom:'12px', color:'blue'}} to='/dashboard'>Dashboard</Link>
            </p>

            <div style={{float:'right'}} >
                {isNext ? 
                <button className='next-button' onClick={changeButton}>Next</button> :
                <div>
                    <button className='back-button' onClick={changeButton}>Back</button>
                    <button className='next-button' style={{paddingLeft:'32px', paddingRight:'32px'}} onClick={register}>Register</button>
                </div>}
            </div>

            <div className='footer'>
             <p>Murdoch username in the form <br /> UC Id (eg. 123456)</p>
            </div>
        </div>
    )
}

export default Register
