import React from 'react'
import axios from 'axios'

import Header from './components/Header'
import Modal from './components/Modal'
import MainBody from './components/MainBody'
import Footer from './components/Footer'

export default class Dashboard extends React.Component {
    
    state = {
        loading: true,
        data: null,
        isAdmin: false,
    }

    componentDidMount() {
        let token = ''
        token = localStorage.getItem('token')
        axios.post('http://localhost:5000/dashboardData',
        {
            auth : 'Bearer '+token,
            Teach_Period: 'JA2021'
        }).then(res =>{
            if(res.data === 'NOTOKAY'){
                window.location.href = '/'
            }
            if(res.data[0].id === 'admin'){
                this.setState({data: res.data, loading: false, isAdmin: true})
            }else{
                this.setState({data: res.data, loading: false, isAdmin:false})
            }
        }).catch(
            ()=>window.location.href = '/'
        )
    }

    render(){
        return <div style={{width:'100%', height:'100%', backgroundColor:'#eff3f5'}}>
            {this.state.loading? <Modal /> : 
            <div>
                <Header isAdmin={this.state.isAdmin} ID={this.state.data[0].user} />
                <MainBody module={this.state.data[1]} />
                <Footer />
            </div>}

        </div>;
    }
}