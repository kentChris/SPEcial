import React from 'react'

function Footer() {
    return (
        <div style={{backgroundColor:'black', marginLeft:'-0.5%', width:'101%', marginBottom:'-0.5%'}}>
             <img style={{width:'168px', height:'36px', marginTop:'15px', paddingBottom:'15px', marginLeft:'20px'}} className='logo' src='https://static.murdoch.edu.au/lms/img/footer-logo.png' alt='logo' />
        </div>
    )
}

export default Footer
