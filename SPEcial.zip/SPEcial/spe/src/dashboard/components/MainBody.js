import React from 'react'
import {Link} from 'react-router-dom'

import '../index.css'
import Pict from '../../module.jpeg'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'

function MainBody({module}) {
    const [date, setDate]= React.useState(new Date())
    return (<>
        <div className='dashboard'>
            <div className='bodyD1'>
            <h2 className='title'>Dashboard</h2>
            <div className='unitOverview'>
                <h5 className='titleUnit'>Unit Overview</h5>
                <hr style={{backgroundColor:'red', height:'3px', marginTop:'-25px'}}></hr>
                {module.map((modules)=>{
                    return(
                        <div key={modules.Unit_Code} className='items'>
                            <Link to={`/module/${modules.Unit_Code}`} style={{textDecoration:'none'}}>
                                <div>
                                    <img style={{width:'300px', height:'112px'}}src={Pict} alt='logo' />
                                    <p style={{ color:'#868E96', fontSize:'15px', marginLeft:'15px'}}>{modules.Teach_Period}</p>
                                    <p style={{color:'#373A3C', fontSize:'15px', fontWeight:'600', marginTop:'-10px', marginLeft:'15px'}}>{modules.Unit_Code} {modules.Name}</p>
                                </div>
                            </Link>
                        </div>
                    )
                })}
            </div>
            </div>
            <div className='bodyD2'>
                <div style={{width:'75%', marginLeft:'15%', marginTop:'15%', border:'0px'}}>
                    <Calendar onChange={setDate} value={date}/>
                </div>
            </div>
            
        </div>
        </>
    )
}

export default MainBody
