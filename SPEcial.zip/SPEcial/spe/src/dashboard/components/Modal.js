import React from 'react'

function Modal() {
    return (
        <div style={{margin:'auto', width:'25%', fontSize: '200%', marginTop: '25%'}}>
            <h1>Please Wait...</h1>
        </div>
    )
}

export default Modal
