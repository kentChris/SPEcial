import React from 'react'
import {Link} from 'react-router-dom'
import '../index.css'
import {AiFillHome, AiOutlineUserAdd} from 'react-icons/ai'
import {GoDiffAdded} from 'react-icons/go'
import {FaUserCircle} from 'react-icons/fa'

function Header({isAdmin, ID}) {
    
    const [modal, setModal]= React.useState(false)

    const handleClick = ()=>{
        setModal(!modal)
    }

    const handleClick1 = ()=>{
        localStorage.setItem('token', '')
        window.location.href = '/'
    }

    return (
        <div>
        <div className='header' className='Header'>
            <img style={{width:'168px', height:'18px', marginTop:'8%', marginLeft:'5%'}} className='logo' src='https://moodleprod.murdoch.edu.au/pluginfile.php/1/core_admin/logocompact/300x300/1632348458/myMurdochLearning-264x27.png' alt='logo' />
            <Link to='/dashboard' style={{color:'white', textDecoration:'none',gridColumnStart:'2'}}><div><p><AiFillHome style={{color:'white'}}/>Dashboard</p></div></Link>
            {isAdmin && <div style={{display:'grid',gridColumnStart:'3', gridTemplateColumns:'70% 70%'}}>
                <Link to='/register' style={{color:'white', textDecoration:'none'}}><p><AiOutlineUserAdd style={{color:'white'}}/>Register</p></Link>
                <Link to='/add' style={{color:'white', textDecoration:'none'}}><p><GoDiffAdded style={{color:'white'}} />Add</p></Link>
            </div>}
               {modal && <p onClick={()=>handleClick1()} style={{color:'white', gridColumnStart:'4', marginLeft:'90%'}}>Sign Out</p>}
               <p onClick={()=>handleClick()} style={{color:'white', gridColumnStart:'5'}}>{ID}<FaUserCircle style={{color:'white', marginLeft:'5px'}}/></p>
          
        </div>
        </div>
    )
}

export default Header


