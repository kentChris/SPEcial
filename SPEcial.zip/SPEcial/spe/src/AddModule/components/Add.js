import React,{useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import '../index.css'

function Add() {
    const [isNext, setIsNext] = useState(true)
    const [modal, setModal] = useState(false)
    let token = ''
    token = localStorage.getItem('token')
    const [people, setPeople] = useState({
        auth:'Bearer '+token,
        Unit_Code: '',
        UC_ID: '',
        Mod_Name: '',
        Teach_Period: '',
    })

    useEffect(()=>{
        setTimeout(() => {
            setModal(false)
        }, 3000);
    },[modal])

    const changeButton = () =>{
        setIsNext(!isNext)
    }

    const handleChange = (e) =>{
        const name = e.target.name
        const value = e.target.value
        setPeople({...people, [name]:value})
    }
    
    const register = () =>{
        axios.post('http://localhost:5000/add',{
        auth: people.auth,
        Unit_Code: people.Unit_Code,
        UC_ID: people.UC_ID,
        Mod_Name: people.Mod_Name,
        Teach_Period: people.Teach_Period,
        }).then((res)=>{
            if(res.data === 'Succesful'){
                window.location.href='/dashboard'
            }else{
                setModal(true)
            }
        }).catch(()=>{
            setModal()
        })
    }

    return (
         <div>
            <img style={{width:'168px', height:'36px', paddingBottom:'16px'}} className='logo' src='https://aadcdn.msauthimages.net/81d6b03a-6qgi2kc8brdyt5zovsmn3p1x0-t-v5-1-hbz0hxnhl4/logintenantbranding/0/bannerlogo?ts=637075786552747320' alt='logo' />
            <h2 style={{marginTop:'0em'}}>Add Module</h2>

            <p>Add a module to an existing UC.</p>
            {modal && <p style={{color:'red'}}>This Module Has been used by other UC</p>}
            

            <input type='text' name={isNext ?'Unit_Code':'UC_ID'}
            placeholder={isNext ? 'Unit Code': 'UC ID'} className='username-input'
            value={isNext? people.Unit_Code: people.UC_ID} onChange={handleChange}/>
            <hr className='line'></hr>

            <input type='text' name={isNext ? 'Mod_Name' : 'Teach_Period'}
            placeholder={isNext? 'Unit Name':'Teach Period'} className='username-input' 
            value={isNext? people.Mod_Name: people.Teach_Period} onChange={handleChange}/>
            <hr className='line'></hr>


            <p>
                 <Link style={{textDecoration:'none', paddingBottom:'12px', color:'blue'}} to='/dashboard'>Dashboard</Link>
            </p>

            <div style={{float:'right'}} >
                {isNext ? 
                <button className='next-button' onClick={changeButton}>Next</button> :
                <div>
                    <button className='back-button' onClick={changeButton}>Back</button>
                    <button className='next-button' style={{paddingLeft:'32px', paddingRight:'32px'}} onClick={register}>Add</button>
                </div>}
            </div>

            <div className='footer'>
             <p>Murdoch username in the form <br /> UC Id (eg. 123456)</p>
            </div>
        </div>
    )
}

export default Add
