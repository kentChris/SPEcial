import React,{useState, useEffect} from 'react'
import { Link, useParams } from 'react-router-dom'
import axios from 'axios'
import '../index.css'

function Register({setIsRegis}) {
  
    const [password, setPassword]= useState('')
    const [confirm, setConfirm] = useState('')
    const [modal, setModal] = useState(false)

    
    const {token} = useParams()
    
    const resetPassword = () =>{
        if(password === confirm){
            axios.put('http://localhost:5000/reset',{
                auth:'Bearer '+token,
                password: password
            }).then(res=>{
                console.log(res.data)
                window.location.href = '/'
            })
        }else{
            setModal(true)
        }
    }

    useEffect(()=>{
        setTimeout(()=>{
        setModal(false)
    },3000)
    },[modal])

    return (
         <div>
            <img style={{width:'168px', height:'36px', paddingBottom:'16px'}} className='logo' src='https://aadcdn.msauthimages.net/81d6b03a-6qgi2kc8brdyt5zovsmn3p1x0-t-v5-1-hbz0hxnhl4/logintenantbranding/0/bannerlogo?ts=637075786552747320' alt='logo' />
            <h2 style={{marginTop:'0em'}}>Reset Password</h2>

            <p>Please enter your new Password</p>

            {modal && <p style={{color:'red'}}>Password and confiramtion password must be the same</p>}
            

            <input type='password' name='password'
            placeholder='Password' className='username-input'
            onChange={(e)=>setPassword(e.target.value)}/>
            <hr className='line'></hr>

            <input type='password' name='confirm'
            placeholder='Password Confirmation' className='username-input' 
            onChange={(e)=> setConfirm(e.target.value)}/>
            <hr className='line'></hr>

            <div style={{float:'right'}} >  
                    <Link to='/' className='back-button'>Back</Link>
                    <button className='next-button' style={{paddingLeft:'32px', paddingRight:'32px'}} onClick={resetPassword}>Reset Password</button>  
            </div>

            <div className='footer'>
             <p>Reseting Password</p>
            </div>
        </div>
    )
}

export default Register
