import React from 'react'
import axios from 'axios';
//React Router
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// Pages
import SignIn from './SignIn'
import DashBoard from './dashboard'
import Register from './register'
import ErrorPage from './Error'
import SetReset from './setPassword'
import Email from './emailPrompt'
import Add from './AddModule'
import Unit from './ModuleUC'
import Create from './CreateSPE'
import SPE from './studentSPE'


function App() {
  return <Router>
    <Switch>
      <Route exact path='/'>
        <SignIn />
      </Route>
      <Route path='/dashBoard'>
        <DashBoard />
      </Route>
      <Route path='/register'>
        <Register />
      </Route>
      <Route path='/setPassword/:token' children={<SetReset />}>
      </Route>
      <Route exact path='/module/:unit' children={<Unit />}>
      </Route>
      <Route path='/createSPE/:unit' children={<Create />}>
      </Route>
      <Route path='/SPE/:token' children={<SPE />}>
      </Route>
      <Route path='/email'>
        <Email />
      </Route>
      <Route path='/add'>
        <Add />
      </Route>
      <Route path='*'>
        <ErrorPage />
      </Route>
    </Switch>
  </Router>
}

export default App;
