-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: SPEcial
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Module`
--

DROP TABLE IF EXISTS `Module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Module` (
  `Unit_Code` char(6) NOT NULL,
  `Teach_Period` char(6) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `UC_ID` char(6) NOT NULL,
  PRIMARY KEY (`Unit_Code`,`Teach_Period`),
  KEY `module_fk` (`UC_ID`),
  CONSTRAINT `module_fk` FOREIGN KEY (`UC_ID`) REFERENCES `unit_coordinator` (`UC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Module`
--

LOCK TABLES `Module` WRITE;
/*!40000 ALTER TABLE `Module` DISABLE KEYS */;
INSERT INTO `Module` VALUES ('ICT123','S22021','Introduction to java','111112'),('ICT123','S32021','Introduction to Java','111114'),('ICT124','S32021','Introduction to Research','111113'),('ICT273','S32021','Data Structure and Abstraction','111113'),('ICT287','S32021','Data Structure and Abstraction','111112'),('ICT302','S32021','Final Year Project','111112'),('ICT345','S32021','Research and development','111112'),('ICT373','S32021','Software Architecture','111112'),('ICT374','S32021','Operating System','111112'),('ICT379','S32021','Security Architecture','111113');
/*!40000 ALTER TABLE `Module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SPE`
--

DROP TABLE IF EXISTS `SPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SPE` (
  `Title` varchar(255) NOT NULL,
  `Due_Date` date NOT NULL,
  `Due_Time` time DEFAULT NULL,
  `Question_1` varchar(255) NOT NULL,
  `Question_2` varchar(255) DEFAULT NULL,
  `Question_3` varchar(255) DEFAULT NULL,
  `Question_4` varchar(255) DEFAULT NULL,
  `Question_5` varchar(255) DEFAULT NULL,
  `Counter` int(11) NOT NULL,
  `Note` varchar(300) DEFAULT NULL,
  `Unit_Code` char(6) NOT NULL,
  `Teach_Period` char(6) NOT NULL,
  `Calculated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Title`,`Unit_Code`,`Teach_Period`),
  KEY `SPE_fk` (`Unit_Code`,`Teach_Period`),
  CONSTRAINT `SPE_fk` FOREIGN KEY (`Unit_Code`, `Teach_Period`) REFERENCES `module` (`Unit_Code`, `Teach_Period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SPE`
--

LOCK TABLES `SPE` WRITE;
/*!40000 ALTER TABLE `SPE` DISABLE KEYS */;
INSERT INTO `SPE` VALUES ('SPE1','2021-11-30','03:23:00','1','2','3','N/A','N/A',3,'Testing','ICT124','S32021',NULL);
/*!40000 ALTER TABLE `SPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student_Module`
--

DROP TABLE IF EXISTS `Student_Module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Student_Module` (
  `Person_ID` char(6) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `Title` varchar(10) NOT NULL,
  `Given_Names` varchar(255) NOT NULL,
  `Teach_Period` char(6) NOT NULL,
  `Unit_Code` char(6) NOT NULL,
  `Team_ID` char(4) NOT NULL,
  `Final_Result` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`Person_ID`,`Unit_Code`,`Teach_Period`),
  KEY `StudMod_fk` (`Unit_Code`,`Teach_Period`),
  CONSTRAINT `StudMod_fk` FOREIGN KEY (`Unit_Code`, `Teach_Period`) REFERENCES `module` (`Unit_Code`, `Teach_Period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student_Module`
--

LOCK TABLES `Student_Module` WRITE;
/*!40000 ALTER TABLE `Student_Module` DISABLE KEYS */;
INSERT INTO `Student_Module` VALUES ('112233','nicole@gmail.com','Sanders','Mrs','Nicole','S32021','ICT287','FT02',0.00),('123456','aidan@gmail.com','Simmons','Mr','Aidan','S32021','ICT124','FT01',0.00),('123456','aidan@gmail.com','Simmons','Mr','Aidan','S32021','ICT287','FT01',0.00),('223344','valentina@gmail.com','Hughes','Mrs','Valentina','S32021','ICT287','FT01',0.00),('234567','harold@gmail.com','Flores','Mr','Harold','S32021','ICT124','FT01',0.00),('234567','harold@gmail.com','Flores','Mr','Harold','S32021','ICT287','FT01',0.00),('334455','rose@gmail.com','Patterson','Mrs','Rose','S32021','ICT287','FT02',0.00),('345678','conner@gmail.com','Bennet','Mr','Conner','S32021','ICT287','FT02',0.00);
/*!40000 ALTER TABLE `Student_Module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student_SPE`
--

DROP TABLE IF EXISTS `Student_SPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Student_SPE` (
  `Person_ID` char(6) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Unit_Code` char(6) NOT NULL,
  `Teach_Period` char(6) NOT NULL,
  `Answer_1` char(3) NOT NULL,
  `Answer_2` char(3) NOT NULL,
  `Answer_3` char(3) NOT NULL,
  `Answer_4` char(3) NOT NULL,
  `Answer_5` char(3) NOT NULL,
  `Teamate_ID` char(6) NOT NULL,
  `Comments` varchar(300) DEFAULT NULL,
  `Score` decimal(5,2) NOT NULL,
  `Percentage` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`Person_ID`,`Title`,`Unit_Code`,`Teach_Period`,`Teamate_ID`),
  KEY `StudSPE_fk` (`Title`,`Unit_Code`,`Teach_Period`),
  CONSTRAINT `StudSPE_fk` FOREIGN KEY (`Title`, `Unit_Code`, `Teach_Period`) REFERENCES `spe` (`Title`, `Unit_Code`, `Teach_Period`),
  CONSTRAINT `StudSPE_fk2` FOREIGN KEY (`Person_ID`) REFERENCES `student_module` (`Person_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student_SPE`
--

LOCK TABLES `Student_SPE` WRITE;
/*!40000 ALTER TABLE `Student_SPE` DISABLE KEYS */;
INSERT INTO `Student_SPE` VALUES ('123456','SPE1','ICT124','S32021','','','','','','123456','',0.00,NULL),('123456','SPE1','ICT124','S32021','','','','','','234567','',0.00,NULL),('234567','SPE1','ICT124','S32021','4','3','2','','','123456','',0.00,50.00),('234567','SPE1','ICT124','S32021','','','','','','234567','',0.00,50.00);
/*!40000 ALTER TABLE `Student_SPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Unit_Coordinator`
--

DROP TABLE IF EXISTS `Unit_Coordinator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Unit_Coordinator` (
  `UC_ID` char(6) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `UC_Name` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UC_ID`),
  UNIQUE KEY `UC_ID` (`UC_ID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Unit_Coordinator`
--

LOCK TABLES `Unit_Coordinator` WRITE;
/*!40000 ALTER TABLE `Unit_Coordinator` DISABLE KEYS */;
INSERT INTO `Unit_Coordinator` VALUES ('111111','ADMIN123','admin@gmail.com','ADMIN',NULL),('111112','kent12345','kent@gmail.com','Kent Chritopher Johansen',NULL),('111113','john123','john@gmail.com','John',NULL),('111114','mark123','mark@gmail.com','Mark','');
/*!40000 ALTER TABLE `Unit_Coordinator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'SPEcial'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-28  3:27:34
